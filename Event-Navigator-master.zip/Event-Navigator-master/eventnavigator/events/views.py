from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.db import connection
from django.utils.safestring import mark_safe
from .db_manage import *
from django.views.decorators.csrf import ensure_csrf_cookie


@ensure_csrf_cookie
def home(request):
    if request.method == 'GET':
        events = get_events(request);
    return render(request, 'home.html', {'events': events['eventList'], 'geoData': events['geoData']})

def organizations(request):
    return render(request, 'organizations.html')

@csrf_exempt
def login(request):
    print('[debug] {}'.format(request.method))
    if request.method == 'POST':
        login_results = login_account(request)
        if login_results['status'] == "error":
            return render(request, 'login.html', {'default_email': mark_safe(login_results['default_email'])})
        else:
         
            return render(request, 'home.html',{'username': login_results['username'] })
    
    return render(request, 'login.html')

# @csrf_except used for 403 errors on POST request, might need another fix.
# see: https://tinyurl.com/yggzrqb3
@csrf_exempt
def register(request):
    if request.method == 'POST':
        register_results = register_account(request)
        if register_results['status'] == "error":
            return render(request, 'register.html', {'values': mark_safe(register_results['default_field_values'])})
        else:
            #TODO: add register-successful notification once reaching login.html
            return render(request, 'login.html')
    return render(request, 'register.html')

def account_details(request):
    return render(request, 'account-detail.html')

def event_details(request):
    return render(request, 'event-detail.html')

def org_details(request):
    return render(request, 'org-detail.html')

def add_event(request):
    return render(request, 'add-event.html')
